<?php

namespace Modules\Refund\Http\Services;

class RefundProductServices
{
    public static function checkEligibility(array $productIds) {

    }
}