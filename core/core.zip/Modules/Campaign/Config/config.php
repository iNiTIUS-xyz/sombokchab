<?php

return [
    'name' => 'Campaign'
];
