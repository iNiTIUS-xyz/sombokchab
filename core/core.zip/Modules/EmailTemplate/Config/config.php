<?php

return [
    'name' => 'EmailTemplate'
];
