<?php

return [
    'name' => 'AdminManage'
];
