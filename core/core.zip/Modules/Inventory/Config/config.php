<?php

return [
    'name' => 'Inventory'
];
