@foreach($deliveryMans as $deliveryMan)
    <x-deliveryman::delivery-man :$deliveryMan />
@endforeach