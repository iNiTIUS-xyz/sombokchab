<?php

return [
    'name' => 'Badge'
];
