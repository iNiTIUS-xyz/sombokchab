<?php

return [
    'name' => 'Attributes'
];
