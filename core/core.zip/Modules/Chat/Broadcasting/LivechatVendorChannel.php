<?php

namespace Modules\Chat\Broadcasting;

use Modules\User\Entities\User;

class LivechatVendorChannel
{
    public function __construct()
    {
    }

    public function join(User $user)
    {

    }
}
