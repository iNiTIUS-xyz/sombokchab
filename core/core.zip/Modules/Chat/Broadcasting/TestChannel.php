<?php

namespace Modules\Chat\Broadcasting;

use Modules\User\Entities\User;

class TestChannel
{
    public function __construct()
    {
    }

    public function join(User $user)
    {

    }
}
